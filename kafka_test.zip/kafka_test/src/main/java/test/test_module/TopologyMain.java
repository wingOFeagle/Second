package test.test_module;

//例2-3 src/main/java/TopologyMain.java
import backtype.storm.Config;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;

public class TopologyMain {
    public static void main(String[] args) throws InterruptedException, AlreadyAliveException, InvalidTopologyException {
    //定义拓扑
        TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout("word-reader", new WordReader());
        builder.setBolt("word-normalizer", new WordNormalizer()).shuffleGrouping("word-reader");
        builder.setBolt("word-counter", new WordCounter(),2).fieldsGrouping("word-normalizer", new Fields("word"));

    //配置

        Config conf = new Config();
        conf.put("wordsFile", args[0]);
		conf.setNumWorkers(2);
		conf.setMaxSpoutPending(100);
    //运行拓扑
        //conf.put(Config.TOPOLOGY_MAX_SPOUT_PENDING, 1);
		System.setProperty("storm.jar","/data/storm/apache-storm-0.9.6/lib/storm-core-0.9.6.jar");
        StormSubmitter.submitTopology("Getting-Started-Topologie", conf, builder.createTopology());
        Thread.sleep(1000);
        //cluster.shutdown();
    }
}